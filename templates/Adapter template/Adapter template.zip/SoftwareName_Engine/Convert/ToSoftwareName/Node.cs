﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BH.oM.Structure.Elements;

namespace BH.Engine.$ext_safeprojectname$
{
    public static partial class Convert
    {
        /***************************************************/
        /**** Public Methods                            ****/
        /***************************************************/

        //Add methods for converting From BHoM to the specific software types, if possible to do without any BHoM calls
        //Example:
        //public static $ext_safeprojectname$Node To$ext_safeprojectname$(this Node node)
        //{
        //    //Insert code for convertion
        //}

        /***************************************************/
    }
}
