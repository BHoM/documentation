﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BH.Engine.$ext_safeprojectname$
{
    public static partial class Convert
    {
        public const string AdapterId = "$ext_safeprojectname$_id";
    }
}
