﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BH.Engine.SoftwareName
{
    public static partial class Convert
    {
        //Key used to find the software in the custom data of created or read objects
        public const string AdapterId = "SoftwareName_id";
    }
}
