﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BH.oM.Structure.Elements;

namespace BH.Engine.SoftwareName
{
    public static partial class Convert
    {
        /***************************************************/
        /**** Public Methods                            ****/
        /***************************************************/

        //Add methods for converting From BHoM to the specific software types, if possible to do without any BHoM calls
        //Example:
        //public static BHoM_Adapter_Template1Node ToBHoM_Adapter_Template1(this Node node)
        //{
        //    //Insert code for convertion
        //}

        /***************************************************/
    }
}
